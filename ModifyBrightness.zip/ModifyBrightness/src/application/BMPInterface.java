package application;

public interface BMPInterface {
	public int getX(); //returneaza width
	public int getY(); //returneaza height
}
